Place here the BVH Files to use in the sketchbook. 
If you want to use the Tree Bones Zoo Free Pack used in our experiments,
pease follow these steps:

1. Visit https://gumroad.com/truebones/p/free-truebones-zoo-over-75-animals-and-animations.
2. It will ask for a method of Payment but, you can omit this using the freecode: truebones4freefree.
3. Place the BVH in the sketch folder and set the "path" variable from the sketchbook with the relative path.




